#include <xc.h>
#include "config.h" 

void main(void) {
//PORT --> ESCRITURA Y LECTURA DE ENTRADAS
//LATD --> ESCRITURA DE SALIDAS
//TRIS --> CONFIGURAR PUERTOS COMO SALIDAS Y ENTRADAS
//ANSEL --> ACTIVR O DESACTIVAR PUERTOS ANALOGICOS

    ANSELB = 0x00;   //Configuro puerto B apagar  anaogica
    
    TRISDbits.TRISD0 = 0;    // RD0 como salida
    TRISDbits.TRISD1 = 0;    // RD1 como salida
    TRISDbits.TRISD2 = 0;    // RD2 como salida
    
    TRISBbits.TRISB0 = 1;    // RB0 como entrada
    TRISBbits.TRISB1 = 1;    // RB1 como entrada
    TRISBbits.TRISB2 = 1;    // RB2 como entrada
    TRISBbits.TRISB3 = 1;    // RB3 como entrada
    
    while (1) {
     
        if (PORTBbits.RB0 == 0) { //SI SE PRESIONA RB0 enciende D2
            
            while (PORTBbits.RB0 == 0);
            
            //LEDs en RD2, RD1 y RD0
            LATDbits.LATD2 = 1;
            LATDbits.LATD1 = 0;
            LATDbits.LATD0 = 0;

            __delay_ms(100);
        }

        if (PORTBbits.RB1 == 0) { //SI SE PRESIONA RB1 enciende D1
 
            while (PORTBbits.RB1 == 0);
            
            // LEDs en RD2, RD1 y RD0
            LATDbits.LATD2 = 0;
            LATDbits.LATD1 = 1;
            LATDbits.LATD0 = 0;

            __delay_ms(100);
        }

        if (PORTBbits.RB2 == 0) { //SI SE PRESIONA RB2 enciende D0
  
            while (PORTBbits.RB2 == 0);
            
            //LEDs en RD2, RD1 y RD0
            LATDbits.LATD2 = 0;
            LATDbits.LATD1 = 0;
            LATDbits.LATD0 = 1;

            __delay_ms(100);
        }

        if (PORTBbits.RB3 == 0) { //SI SE PRESIONA RB3 APAGAR TODOS
 
            while (PORTBbits.RB3 == 0);
            
            // Apaga todos los LEDs
            LATDbits.LATD2 = 0;
            LATDbits.LATD1 = 0;
            LATDbits.LATD0 = 0;

            __delay_ms(100);
        }
    }
    
    return;
}

