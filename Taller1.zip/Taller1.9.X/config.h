

#ifndef COFIG_H
#define	COFIG_H


#define _XTAL_FREQ 20000000UL


#endif	/* COFIG_H */

