
#include <xc.h>
#include "config.h"

#define espera 1000
char i;

void main (void) {
    TRISD = 0x00;
    TRISAbits.TRISA0 = 1;
    ANSELAbits.ANSA0 = 0; 
    TRISAbits.TRISA1 = 1;
    ANSELAbits.ANSA1 = 0; 
    
    
    while (1) {
        //encender de izquierda a derecha
        
        for (i = 0; i < 8; i++) {
            PORTD = (1 << i);
            __delay_ms(espera);
        }
        //regresar
        for (i = 6; i >= 1; i--){
            PORTD = (1 << i);
            __delay_ms(espera);
        }
        /* Mi opinion, segun lo elaborado es que las mascaras de bits son un metodo mas eficaz a la hora
        de aplicarse en la practica ya que por temas de escritura tiene menos riesgo de error*/ 
    }
    return;
}