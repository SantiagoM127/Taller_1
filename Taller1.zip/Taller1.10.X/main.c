
#include <xc.h>
#include "config.h"

void main(void) {
 
    ANSELB = 0x00; 
    TRISDbits.TRISD0 = 0; //RD0 como salida
    TRISBbits.TRISB0 = 1; //RB0 como entrada
    TRISBbits.TRISB1 = 1; //RB1 como entrada
    
    while (1) { 
        if (PORTBbits.RB0 == 0) { // SI RB0 ESTA PRESIONADO ENCENDER LED
            while (PORTBbits.RB0 == 0);
            
            // Invertir el estado de RD0 (LED) utilizando XOR
            LATDbits.LATD0 ^= 1;
            
            __delay_ms(100);                        //UN BOTON HACE LO CONTRARIO DEL OTRO 
                                                    //AL NO SABER EL ESTADO SOLO SE SABE QUE LO INVIERTE
        }
     
        if (PORTBbits.RB1 == 0) { // SI RB ESTA PRESIONADO ENCENDER LED

            while (PORTBbits.RB1 == 0);
            
            // Invertir el estado de RD0 (LED) utilizando XOR
            LATDbits.LATD0 ^= 1;

            __delay_ms(100);
        }
    }
    
    return;
}