
#include <xc.h>
#include "config.h"

char cuenta = 0; // declaro cuenta = 0

void main (void) {
    TRISBbits.TRISB0 = 1; //RB0 = ENTRADA 
    ANSELBbits.ANSB0 = 0; //RB0 = ENTRADA DIGITAL 
    TRISBbits.TRISB7 = 0; //RB7 = SALIDA LED
    
    TRISD = 0x00; // PUERTO D salida 
    PORTD = 0x00; // INICIAlIZA APAGADOS 
    
    while (1) {
        // RB0 inicia presionado 
        if(PORTBbits.RB0 == 0){
            //Despresioanr el boton
            while (PORTBbits.RB0 == 0);
            
            //Aumentar la cuenta hasta que llegue a 5
            cuenta++;
            if (cuenta == 5) {
                //Invertir el estado del LED en RB7
                LATBbits.LATB7 ^= 1;
            }
        }
        __delay_ms(150);
    }
    return;
}
