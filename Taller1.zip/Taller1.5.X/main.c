
#include <xc.h>
#include "config.h"

//DAR LA ORDEN DE DE INICIAR SECUENCIAS

//PORT --> ESCRITURA Y LECTURA DE ENTRADAS
//LATD --> ESCRITURA DE SALIDAS
//TRIS --> CONFIGURAR PUERTOS COMO SALIDAS Y ENTRADAS
//ANSEL --> ACTIVR O DESACTIVAR PUERTOS ANALOGICOS

int valor_secuencia;

void main (void){
    
    TRISD = 0x00; //PUERTO  D SALIDA
    ANSELD = 0x00; //APAGAR LO ANALOGICO
    TRISB = 0xF0; //PUERTO B (ENTRADAS 4)
    
    while(1){ 
        valor_secuencia = (PORTB & 0xF0)>>4; //leer valor secuencia por la entrada
        switch(valor_secuencia){
            case 0: Secuencia00(); break;
            case 1: Secuencia01(); break;
            case 2: Secuencia02(); break;
            case 3: Secuencia03(); break;
            case 4: Secuencia04(); break;
            case 5: Secuencia05(); break;
            case 6: Secuencia06(); break;
            case 7: Secuencia07(); break;
            case 8: Secuencia08(); break;
            case 9: Secuencia09(); break;
        }
        __delay_ms(150); //velocidad 
    }
    
    return;
}