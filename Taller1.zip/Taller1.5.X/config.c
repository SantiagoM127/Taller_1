

// PIC16F1939 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = HS        // Oscillator Selection (HS Oscillator, High-speed crystal/resonator connected between OSC1 and OSC2 pins)
#pragma config WDTE = OFF       // Watchdog Timer Enable (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable (PWRT disabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select (MCLR/VPP pin function is MCLR)
#pragma config CP = OFF         // Flash Program Memory Code Protection (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Memory Code Protection (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable (Brown-out Reset disabled)
#pragma config CLKOUTEN = OFF   // Clock Out Enable (CLKOUT function is disabled. I/O or oscillator function on the CLKOUT pin)
#pragma config IESO = ON        // Internal/External Switchover (Internal/External Switchover mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable (Fail-Safe Clock Monitor is enabled)

// CONFIG2
#pragma config WRT = OFF        // Flash Memory Self-Write Protection (Write protection off)
#pragma config VCAPEN = OFF     // Voltage Regulator Capacitor Enable (All VCAP pin functionality is disabled)
#pragma config PLLEN = ON       // PLL Enable (4x PLL enabled)
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable (Stack Overflow or Underflow will cause a Reset)
#pragma config BORV = LO        // Brown-out Reset Voltage Selection (Brown-out Reset Voltage (Vbor), low trip point selected.
#pragma config LVP = OFF        // Low-Voltage Programming Enable (High-voltage on MCLR/VPP must be used for programming)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h> //LIBRERIA
#include"config.h"
//CONFIGURAR LOS LEDS QUE SE VAN A ENCENDER EN CADA SECUENCIA
void Secuencia00(){
    //Apagar todos los leds para iniciar
    LATD = 0;
    __delay_ms(150);
}

void Secuencia01(){
    //Encender leds D0 Y D2
    LATD = 0b00000101;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

void Secuencia02(){
    //AEncender leds D2 y D4
    LATD = 0b00010100;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

void Secuencia03(){
    //Encender leds D4 Y D6
    LATD = 0b01010000;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

void Secuencia04(){
    //Encender leds D7 Y D5
    LATD = 0b10100000;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

void Secuencia05(){
    //Encender leds D5 Y D3
    LATD = 0b00101000;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

void Secuencia06(){
    //Encender leds D3 Y D1
    LATD = 0b00001010;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

void Secuencia07(){
    //Encender leds D7 Y D6
    LATD = 0b11000000;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

void Secuencia08(){
    //Encender leds D0 Y D1
    LATD = 0b00000011;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}

//void Secuencia09(){
//    //Encender leds D5 Y D4
//    LATD = 0b00110000;
//    __delay_ms(150);
//    LATD = 0; //Apagar los leds 
//    __delay_ms(150);
//}

void Secuencia09(){
    //Encender leds D2 Y D3
    LATD = 0b00001100;
    __delay_ms(150);
    LATD = 0; //Apagar los leds 
    __delay_ms(150);
}