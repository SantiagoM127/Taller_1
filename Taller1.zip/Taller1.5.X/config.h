
#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 200000000UL //frecuencia del pic
//DEFINIR LAS SECUENCIAS (LO QUE VOY A LLAMAR)
void Secuencia00();
void Secuencia01();
void Secuencia02();
void Secuencia03();
void Secuencia04();
void Secuencia05();
void Secuencia06();
void Secuencia07();
void Secuencia08();
void Secuencia09();


#endif	/* CONFIG_H */

