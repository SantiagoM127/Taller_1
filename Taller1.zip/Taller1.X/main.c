#include <xc.h>
#include "config.h"

#define espera 1000

void main (){
    TRISD = 0x00;
    LATD = 0x00;
    
    
    while(1){
        LATD = 0b00000001;
    __delay_ms(espera);
    LATD = 0b00000010;
    __delay_ms(espera);
    LATD = 0b00000100;
    __delay_ms(espera);
    LATD = 0b00001000;
    __delay_ms(espera);
    LATD = 0b00010000;
    __delay_ms(espera);
    LATD = 0b00100000;
    __delay_ms(espera);
    LATD = 0b01000000;
    __delay_ms(espera);
    LATD = 0b10000000;
    __delay_ms(espera);
LATD = 0b01000000;
    __delay_ms(espera);
    LATD = 0b00100000;
    __delay_ms(espera);
    LATD = 0b00010000;
    __delay_ms(espera);
    LATD = 0b00001000;
    __delay_ms(espera);
    LATD = 0b00000100;
    __delay_ms(espera);
    LATD = 0b00000010;
    __delay_ms(espera);
    LATD = 0b00000001;
    __delay_ms(espera);
    }
    
    
    return;
   
}
