#include <xc.h> //LIBRERIAS
#include "config.h"

void main(void){
    
    TRISD= 0x00; //CNFIGURAR PUERTO D COMO SALIDAS
    
    TRISAbits.TRISA0 = 1; //CONFIGURAR PUERTO A01 COMO ENTRADA
    ANSELAbits.ANSA0 = 0; //APAGAR PUERTO A ANALOGICO
    TRISAbits.TRISA1 = 1;
    ANSELAbits.ANSA1 = 0;
    
    /*0,0 Frenado
      0,1 Drecha
      1,0 Izquierda/*/

    while(1){
        
        if(PORTAbits.RA0 == 1 && PORTAbits.RA1 == 0){ //SI BOTON 1 ESTA PRESIONADO Y BOTON 2 NO, PONER 1 EN PUETO D0
            
            LATDbits.LATD0 = 1; //LATD PORQUE ES ESCRITURA
            LATDbits.LATD1 = 0;
            
        }else if(PORTAbits.RA0 == 0 && PORTAbits.RA1 == 1){ //PERO SI BOTON 1 NO ESTA PRESIONADO Y BOTON 2 SI, PONER 1 EN PUETO D1
            
            LATDbits.LATD0 = 0;
            LATDbits.LATD1 = 1;
            
        }else{ //SI AMBOS ESTAN EN 0 O EN 1 LAS DOS SALIDAS ESTAN EN 0
            LATDbits.LATD0 = 0;
            LATDbits.LATD1 = 0;
        }
    }       
    return;
}
