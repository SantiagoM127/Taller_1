

#ifndef CONFIG_H
#define	CONFIG_H

#define _XTAL_FREQ 200000000UL


#endif	/* CONFIG_H */

